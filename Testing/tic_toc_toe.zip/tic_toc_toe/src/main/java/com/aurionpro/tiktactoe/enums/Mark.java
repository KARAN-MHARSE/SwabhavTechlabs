package com.aurionpro.tiktactoe.enums;

public enum Mark {
	X,O,None;
}
